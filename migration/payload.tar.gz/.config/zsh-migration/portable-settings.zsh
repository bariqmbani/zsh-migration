alias cb='cd ..'
export GOPROXY=https://proxy.golang.org,direct
export GO111MODULE=on
export CGO_LDFLAGS_ALLOW='.*'
export GOLANG_PROTOBUF_REGISTRATION_CONFLICT=warn
