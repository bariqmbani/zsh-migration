ZSH_THEME=robbyrussell
plugins=(git zsh-autosuggestions zsh-syntax-highlighting zsh-ai zsh-history-substring-search)
