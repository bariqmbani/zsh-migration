export ZSH_AI_PROVIDER="openai"
export ZSH_AI_OPENAI_URL="https://9r.uwurl.xyz/v1/chat/completions"
export ZSH_AI_OPENAI_MODEL="warp-cli-agent"
