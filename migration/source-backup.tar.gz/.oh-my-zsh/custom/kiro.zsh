# Kiro IDE — open the current (or given) directory from WSL with WSL remoting,
# mirroring VS Code's `code .`. Requires the jeanp413.open-remote-wsl extension
# and "enable-proposed-api" for it in Kiro's argv.json (both already set up).
_KIRO_EXE=$(find /mnt/c/Users/*/AppData/Local/Programs/Kiro/Kiro.exe 2>/dev/null | head -1)
if [ -n "$_KIRO_EXE" ]; then
  kiro() {
    local kiro_dir="${_KIRO_EXE%/Kiro.exe}"
    local cli
    cli=$(wslpath -m "$kiro_dir/resources/app/out/cli.js")
    local target="${1:-.}"
    if [ -d "$target" ]; then
      target="$(cd "$target" && pwd)"
      WSLENV="ELECTRON_RUN_AS_NODE/w:$WSLENV" ELECTRON_RUN_AS_NODE=1 \
        "$_KIRO_EXE" "$cli" \
        --folder-uri "vscode-remote://wsl+${WSL_DISTRO_NAME}${target}" &>/dev/null &
    else
      WSLENV="ELECTRON_RUN_AS_NODE/w:$WSLENV" ELECTRON_RUN_AS_NODE=1 \
        "$_KIRO_EXE" "$cli" "$target" &>/dev/null &
    fi
    disown
  }
fi
