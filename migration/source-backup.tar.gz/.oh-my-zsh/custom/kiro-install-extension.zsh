# Install a VS Code extension into Kiro from Open VSX (Kiro's marketplace),
# since Kiro's own --install-extension against a running instance doesn't
# reliably work over IPC. Downloads the .vsix and installs it headlessly.
#
# Usage: kiro-install <publisher.extension-name> [version]
#   kiro-install ms-python.python
#   kiro-install k--kato.intellij-idea-keybindings 1.7.7
kiro-install() {
  if [ -z "$1" ]; then
    echo "Usage: kiro-install <publisher.extension-id> [version]"
    return 1
  fi

  local ext="$1"
  local publisher="${ext%%.*}"
  local name="${ext#*.}"
  local version="$2"

  local kiro_exe
  kiro_exe=$(find /mnt/c/Users/*/AppData/Local/Programs/Kiro/Kiro.exe 2>/dev/null | head -1)
  if [ -z "$kiro_exe" ]; then
    echo "Could not find Kiro.exe under /mnt/c/Users/*/AppData/Local/Programs/Kiro/"
    return 1
  fi

  if [ -z "$version" ]; then
    version=$(curl -s "https://open-vsx.org/api/${publisher}/${name}/latest" | python3 -c "import json,sys; print(json.load(sys.stdin)['version'])" 2>/dev/null)
    if [ -z "$version" ]; then
      echo "Could not resolve latest version for ${ext} on Open VSX. Check the id, or pass a version explicitly."
      return 1
    fi
  fi

  local vsix_url="https://open-vsx.org/api/${publisher}/${name}/${version}/file/${publisher}.${name}-${version}.vsix"
  local win_tmp_wsl="/mnt/c/Users/$(whoami)/AppData/Local/Temp/${publisher}.${name}-${version}.vsix"
  # Fall back to the Windows user dir matching the Kiro.exe path found above
  # in case the WSL username differs from the Windows one.
  if [ ! -d "$(dirname "$win_tmp_wsl")" ]; then
    win_tmp_wsl="${kiro_exe%/AppData/*}/AppData/Local/Temp/${publisher}.${name}-${version}.vsix"
  fi

  echo "Downloading ${ext}@${version} from Open VSX..."
  if ! curl -sL -o "$win_tmp_wsl" "$vsix_url" || [ ! -s "$win_tmp_wsl" ]; then
    echo "Download failed. Check the extension id/version exists on https://open-vsx.org/extension/${publisher}/${name}"
    rm -f "$win_tmp_wsl"
    return 1
  fi

  local kiro_dir="${kiro_exe%/Kiro.exe}"
  local cli win_vsix
  cli=$(wslpath -m "$kiro_dir/resources/app/out/cli.js")
  win_vsix=$(wslpath -w "$win_tmp_wsl")

  WSLENV="ELECTRON_RUN_AS_NODE/w:$WSLENV" ELECTRON_RUN_AS_NODE=1 \
    "$kiro_exe" "$cli" --install-extension "$win_vsix"

  rm -f "$win_tmp_wsl"
  echo "Done. Reload the Kiro window (Command Palette -> Developer: Reload Window) to activate it."
}
