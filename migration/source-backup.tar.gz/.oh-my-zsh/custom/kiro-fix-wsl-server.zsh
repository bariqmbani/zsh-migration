# Fix Kiro's WSL remote server after it breaks (typically after a Kiro
# update bumps the server commit hash). Known failure mode on this network:
# the download is slow, Kiro's extension times out and kills the install
# script mid-download, leaving a corrupted/incomplete vscode-server.tar.gz
# that every retry then reuses and fails to extract. This wipes the stale
# install, triggers a fresh connection, and if the extension gives up again
# mid-download, finishes the install manually (extract + launch) instead of
# looping on the same corrupted archive.
#
# Usage: kiro-fix-wsl [path]   (path defaults to current directory)
kiro-fix-wsl() {
  local target="${1:-.}"
  local server_data_dir="$HOME/.kiro-server"

  echo "==> Wiping stale WSL server install ($server_data_dir)"
  rm -rf "$server_data_dir"

  echo "==> Triggering a fresh connection (kiro $target)"
  kiro "$target"

  echo "==> Waiting for the server bundle download to start..."
  local waited=0
  while [ ! -d "$server_data_dir/bin" ] && [ $waited -lt 60 ]; do
    sleep 2; waited=$((waited + 2))
  done
  if [ ! -d "$server_data_dir/bin" ]; then
    echo "No download started within 60s. Is Kiro open and did the WSL window try to connect?"
    return 1
  fi

  local commit_dir
  commit_dir=$(ls -t "$server_data_dir/bin" | head -1)
  local server_dir="$server_data_dir/bin/$commit_dir"
  local tarball="$server_dir/vscode-server.tar.gz"

  echo "==> Waiting for download to finish (commit $commit_dir)..."
  waited=0
  while pgrep -f "kiro-reh-linux" > /dev/null && [ $waited -lt 900 ]; do
    sleep 5; waited=$((waited + 5))
  done

  if [ ! -f "$tarball" ]; then
    echo "No tarball found at $tarball — Kiro's own install may have already finished normally. Checking for a running server..."
  elif ! tar -tzf "$tarball" > /dev/null 2>&1; then
    echo "Downloaded archive is corrupted/incomplete. Re-run kiro-fix-wsl to retry the download."
    return 1
  fi

  if pgrep -f "$server_dir/bin/kiro-server" > /dev/null; then
    echo "==> Server already running normally, nothing more to do."
    return 0
  fi

  if [ -f "$tarball" ]; then
    echo "==> Archive is valid but wasn't extracted (Kiro likely timed out waiting) — finishing manually"
    ( cd "$server_dir" && tar -xf vscode-server.tar.gz --strip-components 1 )
    rm -f "$tarball" "$server_dir/wget-log"

    if [ ! -f "$server_dir/bin/kiro-server" ]; then
      echo "Extraction did not produce bin/kiro-server — something else is wrong. Check $server_dir manually."
      return 1
    fi

    local logfile="$server_data_dir/.$commit_dir.log"
    local pidfile="$server_data_dir/.$commit_dir.pid"
    local tokenfile="$server_data_dir/.$commit_dir.token"

    touch "$tokenfile"; chmod 600 "$tokenfile"
    (uuidgen 2>/dev/null || python3 -c "import uuid; print(uuid.uuid4())") > "$tokenfile"

    nohup "$server_dir/bin/kiro-server" --start-server --host=127.0.0.1 --port=0 \
      --connection-token-file "$tokenfile" --telemetry-level off --use-host-proxy \
      --disable-websocket-compression --without-browser-env-var \
      --enable-remote-auto-shutdown --accept-server-license-terms \
      > "$logfile" 2>&1 &
    echo $! > "$pidfile"
    disown

    sleep 3
    echo "==> Server log:"
    cat "$logfile"

    echo "==> Reconnecting Kiro to pick up the now-running server"
    kiro "$target"
  fi

  echo "==> Done. Check the Kiro window — it should connect within a few seconds."
}
