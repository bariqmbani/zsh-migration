# Setup fzf
# ---------
# Prefer the matching fzf installation over older system packages.
path=("$HOME/.fzf/bin" ${path:#"$HOME/.fzf/bin"})
export PATH

# Shell widgets require an interactive line editor.
if [[ -o interactive && -o zle && -t 0 ]]; then
  source <(fzf --zsh)
fi
